#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 23 15:03:28 2019

@author: lavanyasingh
"""

"""commentdater.__main__: executed when commentdater directory is called as script."""

from .src import main
main()
